#!/bin/bash
docker start foot
echo "Docker foot started"