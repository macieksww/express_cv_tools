#!/bin/bash
docker stop foot
echo "Docker foot stopped"