#!/bin/bash
docker stop nominatim
echo "Docker nominatim stopped"