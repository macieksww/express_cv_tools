#!/bin/bash
docker start nominatim
echo "Docker nominatim started"