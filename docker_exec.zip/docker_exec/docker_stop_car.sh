#!/bin/bash
docker stop car
echo "Docker car stopped"