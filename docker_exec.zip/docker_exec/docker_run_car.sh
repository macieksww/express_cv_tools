#!/bin/bash
docker start car
echo "Docker car started"