#!/bin/bash
docker start bike
echo "Docker bike started"