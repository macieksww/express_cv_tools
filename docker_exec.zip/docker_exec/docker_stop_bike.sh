#!/bin/bash
docker stop bike
echo "Docker bike stopped"